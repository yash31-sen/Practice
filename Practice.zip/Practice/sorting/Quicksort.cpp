/*
In quick sort (devide and conquore):
1) we partition the array and place 1 element to its correct position
2) the element those are lessser than the already stored element are placed to the left of that element and the
element those are grater are placed to the right of that element.


Algorithm:
1)select one element as pivot (generally 1st element )
2) count the total number of elements lesser to the pivot
3) change the position of pivot to start+(count of all the lesser element to the pivot );
4) Now take 2 pointers i and j (i points to 1st element and j points to last element);
5) compare them if i>pivot them swap it with j and if j<pivot then swap it with i  else leave them as it is
6) Call it recurssively

Questions based on Quick sort:
1)what is the time complexity of quick sort?
ANS=>   Best case	 O(n log n)  (pivot[choosen radomly] is median or array)
        Average case O(n log n)  (pivot[chooosen randomly] is not madian of array)
        Worst case	 O(n^2)  (pivot smallest or largest element of array)

*/

#include <iostream>
using namespace std;
// int partition(int *arr, int s, int e)// not handeling large inputs work with small sized inputs
// {
//     int pivot = arr[s];
//     int c = 0;
//     for (int i = s + 1; i <= e; i++)
//     {
//         if (arr[i] < pivot)
//         {
//             c++;
//         }
//     }
//     int pivotIndex = s + c;
//     // changing position of pivot
//     swap(arr[pivotIndex], arr[s]);
//     int i = s, j = e;
//     while (i < pivotIndex && j > pivotIndex)
//     {
//         while (arr[i] <= pivot)
//         {
//             i++;
//         }
//         while (arr[j] > pivot)
//         {
//             j--;
//         }

//         if (i < pivotIndex && j > pivotIndex)
//         {
//             swap(arr[i++], arr[j--]);
//         }
//     }

//     return pivotIndex;
// }

// new partition function:

int partition(int *arr, int s, int e)//work well for every input 
{
    int pivot = arr[s];
    int i = s + 1;
    int j = e;

    while (true)
    {
        while (i <= j && arr[i] <= pivot)
        {
            i++;
        }
        while (i <= j && arr[j] > pivot)
        {
            j--;
        }
        if (i <= j)
        {
            swap(arr[i], arr[j]);
        }
        else
        {
            break;
        }
    }

    swap(arr[s], arr[j]);
    return j;
}
void quickSort(int *arr, int s, int e)
{
    if (s >= e)
    {
        return;
    }

    int p = partition(arr, s, e);

    // for left part

    quickSort(arr, s, p - 1);

    // for right part
    quickSort(arr, p + 1, e);
}

int main()
{
    int arr[] = {4, 1, 3, 9, 7};
    int n = 5;

    //  int arr[10] = {2,4,1,6,9 ,9,9,9,9,9};
    //     int n = 10;
    quickSort(arr, 0, n - 1);
    for (int i = 0; i < n; i++)
    {
        cout << arr[i] << " ";
    }
    cout << endl;
    return 0;
}

#include <iostream>
using namespace std;

class node
{
public:
    int data;
    node *left;
    node *right;

    node(int d)
    {
        this->data = d;
        this->left = NULL;
        this->right = NULL;
    }
};

node *buildTree(node *root)
{
    cout << "Enter the value of root: ";
    int data;
    cin >> data;
    root = new node(data);
    if (data == -1)
    {
        return NULL;
    }
    cout << "Entert data for inserting in the left: " << data << ": ";
    root->left = buildTree(root->left);
    cout << "Enter data for inserting in the right of " << data << ": ";
    root->right = buildTree(root->right);
    return root;
}



void levelOrderTraversal(node* root){
    
}

int main()
{

    node* root=NULL;
    buildTree(root);

    return 0;
}
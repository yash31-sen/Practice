// #include <iostream>
// using namespace std;
// int main()
// {
//     const int n = 4;
//     int e = n - 1;
//     int s = 0;
//     int arr[n] = {1, 2, 3, 4};
//     while (s < e)
//     {

//         // //swap 1
//         // swap(arr[s],arr[e]);

//         ////  swap2
//         // int temp=arr[s];
//         // arr[s]=arr[e];
//         // arr[e]=temp;
        
//         //// swap 3
//         // arr[s]=arr[s]+arr[e];
//         // arr[e]=arr[s]-arr[e];
//         // arr[s]=arr[s]-arr[e];

//         s++;
//         e--;
//     }

//     for (int i = 0; i < n; i++)
//     {
//         cout << arr[i] << " ";
//     }
//     return 0;
// }





#include<iostream>
using namespace std;
int main()
{
int arr[]={1,2,3};
int arr1[]={4,5,6};

return 0;
}
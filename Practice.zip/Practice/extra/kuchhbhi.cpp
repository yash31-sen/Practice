#include <iostream>
using namespace std;
class node
{
public:
    int data;
    node *next;
    node(int data)
    {
        this->data = data;
        next = NULL;
    }
};

void insertAtTail(node *&head, int val)
{
    node *n = new node(val);
    if (head == NULL)
    {
        head = n;
        return;
    }
    node *temp = head;
    while (temp->next != NULL)
    {
        temp = temp->next;
    }

    temp->next = n;
}

void insertInBtw(node *head, int q, int val)
{
    node *newNode = new node(val);
    node *cur = head;
    while (cur->next != NULL)
    {
        if (cur->data == q)
        {
            cur->next = newNode;
            newNode->next = cur->next->next;
            break;
        }
    }
}

void insertAtHead(node *&head, int val)
{
    node *n = new node(val);
    n->next = head;
    head = n;
}

void print(node *&head)
{
    node *cur = head;
    while (cur != NULL)
    {
        cout << cur->data << "->";
        cur = cur->next;
    }
    cout << "NULL";
}

int main()
{
    node *head = NULL;
    insertAtTail(head, 3);
    insertAtTail(head, 3);
    insertAtHead(head, 30);
    insertAtTail(head, 35);
    insertAtTail(head, 35);
    print(head);
    return 0;
}
/*
Doubly Linked List:
it is a type of linked list which contains 3 fields in its node ( next pointer ,prev pointer and data)
every node has 2 pointers prev and next

*/

#include <iostream>
using namespace std;
class node
{
public:
    int data;
    node *next;
    node *prev;
    node(int data)
    {
        next = NULL;
        prev = NULL;
        this->data = data;
    }
};

void print(node *head)
{
    node *cur = head;
    while (cur != NULL)
    {
        cout << cur->data << " ";
        cur = cur->next;
    }
}

int getLength(node *head)
{
    node *cur = head;
    int len = 0;
    while (cur != NULL)
    {
        len++;
        cur = cur->next;
    }
    return len;
}

void insertAtHead(node *&head, int val)
{
    node *temp = new node(val);
    temp->next = head;
    head->prev = temp;
    head = temp;
}

void insertAtTail(node *tail, int val)
{
    node *n = new node(val); // created node
    if (tail == NULL)        // if no element present
    {
        tail = n;
        return;
    }
    node *temp = tail;
    while (temp->next != NULL) // if element present then reach to the last element
    {
        temp = temp->next;
    }
    temp->next = n;
    n->prev = temp;
    tail = temp;
}

void insertInBtw(node *head, int pos, int data)
{
    node *cur = head;
    node *n = new node(data);
    while (cur->data != pos)
    {
        cur = cur->next;
    }
    cur->next->prev = n;
    n->next = cur->next;
    cur->next = n;
    n->prev = cur;
}

int main()
{
    node *node1 = new node(10);
    node *head = node1;
    // insertAtHead(head, 11);
    insertAtTail(head, 9);
    insertInBtw(head, 10, 45);
    print(head);
    // cout << getLength(head);
    return 0;
}
